# CodeMind AI – Phase-Wise Implementation Plan

## Project objective

Build a responsive AI-powered GitHub Code Reviewer dashboard that triggers an existing n8n workflow and displays the actual code-review response.

### Fixed integration assumptions

* The GitHub repository URL is already supplied inside the existing n8n workflow to its GitHub HTTP Request node.
* The production url from n8n http://localhost:5678/webhook/Github\_review
* The frontend must not ask users to enter a GitHub repository URL.
* The frontend triggers the existing n8n webhook.
* The integration is synchronous: the frontend waits for the webhook's HTTP response.
* Do not implement job IDs, polling, WebSockets or server-sent events.
* The actual n8n response schema is not yet available. A proposed JSON contract must be agreed and mapped before final results rendering.
* Do not use fabricated review results or scores in the working application.

\---

## Phase 0 – Confirm the n8n contract and integration details

### Goal

Confirm how the existing workflow is triggered and exactly what it returns before building the integration.

### Implementation tasks

1. Identify the production/test webhook URL and HTTP method.
2. Confirm whether the webhook expects a request body, headers or authentication.
3. Run the existing workflow once and capture its actual final response.
4. Confirm the final n8n node returns JSON and an appropriate HTTP status.
5. Agree on a stable response contract for repository metadata, scores, findings, recommendations and errors.
6. Decide which review-module selections, if any, the workflow accepts from the frontend.
7. Confirm CORS behavior, or decide to use a backend proxy.

### Deliverables

* Webhook configuration details.
* Actual sample n8n response.
* Agreed response JSON contract.
* Integration decision: direct browser-to-webhook for a safe test setup, or backend proxy for production.

### Acceptance criteria

* A manual request can trigger the workflow successfully.
* The final response can be captured and understood.
* The frontend request payload and response fields are documented.

**Gate:** Do not finalize the result renderer until the real response shape is known. The proposed JSON in the UI prompt is only a target contract, not evidence of the current n8n output.

\---

## Phase 1 – Application foundation and visual design

### Goal

Create the CodeMind AI application shell and visual design system.

### Implementation tasks

1. Create the project structure and application entry point.
2. Establish the dark navy, cyan and blue visual theme.
3. Add typography, spacing, color and component design tokens.
4. Build the responsive page layout.
5. Add the sticky header, logo and navigation.
6. Create reusable cards, buttons, badges, tables, modals and empty states.
7. Add responsive behavior for desktop, tablet and mobile.

### Deliverables

* Working dashboard shell.
* Reusable visual components.
* Responsive styling.

### Acceptance criteria

* The application loads without console errors.
* Navigation and layout render correctly at common screen sizes.
* No backend integration is required yet.

\---

## Phase 2 – Dashboard and review controls

### Goal

Build the dashboard users interact with before starting a review.

### Implementation tasks

1. Create the Repository Code Analyzer control panel.
2. Add review-module checkboxes:

   * Code Quality
   * Security Analysis
   * Performance
   * Coding Standards
   * Maintainability
   * Test Automation Review
3. Add Select All and clear-selection behavior.
4. Add the Start Code Review button.
5. Do not add a GitHub repository URL field.
6. Add dashboard metric cards, but show neutral empty states or clearly marked historical metrics until real data exists.
7. Add the initial Review Workspace waiting state.

### Deliverables

* Functional review controls.
* Dashboard overview.
* Empty and waiting states.

### Acceptance criteria

* Users can select and deselect review modules.
* Start Code Review is disabled if no required module is selected.
* No GitHub URL is requested from the user.
* No fabricated metrics are presented as real data.

\---

## Phase 3 – n8n synchronous API integration

### Goal

Connect the Start Code Review action to the existing n8n webhook.

### Implementation tasks

1. Create a dedicated configuration module for the webhook endpoint.
2. Create a separate API service module for the HTTP request.
3. On button click, validate the selected modules.
4. Send the agreed POST request to the n8n webhook.
5. Include only the request fields that the actual workflow expects.
6. Await the complete HTTP response.
7. Check HTTP status and handle non-success responses.
8. Parse JSON safely and handle invalid or empty response bodies.
9. Add a sensible request timeout.
10. Re-enable the button in a finally block.
11. Prevent accidental duplicate submissions while a request is in progress.

### Deliverables

* Working synchronous webhook call.
* Centralized API and configuration modules.
* Network and HTTP error handling.

### Acceptance criteria

* Clicking Start Code Review triggers exactly one workflow request.
* The frontend waits for the response.
* The UI recovers after success, failure or timeout.
* No polling, job IDs, WebSockets or SSE are introduced.
* Production credentials are not exposed in frontend code.

\---

## Phase 4 – Loading, success and failure experience

### Goal

Make the waiting experience clear without implying access to workflow progress events that do not exist.

### Implementation tasks

1. Disable the review button while the request is pending.
2. Show an indeterminate spinner or animated scanning indicator.
3. Display rotating informational messages such as:

   * Sending review request...
   * Waiting for repository analysis...
   * Waiting for AI review results...
   * Preparing the report...
4. Clearly treat these as general waiting messages, not confirmed n8n node events.
5. On success, show a completion state and proceed to results.
6. On failure, show a meaningful error card and Retry action.
7. Preserve the page state so a failed request does not break the dashboard.

### Deliverables

* Loading state.
* Success state.
* Error and retry states.

### Acceptance criteria

* No fake percentage progress is displayed.
* The UI does not claim a particular workflow stage completed unless the backend actually reports it.
* Retry triggers a new request only after the previous request has ended.

\---

## Phase 5 – Response normalization and review results

### Goal

Convert the actual n8n response into a stable frontend data model and render the report.

### Implementation tasks

1. Capture and inspect the real n8n JSON response.
2. Implement a response adapter that maps actual fields into the agreed UI model.
3. Support the actual response envelope, including a single object or a one-item array if applicable.
4. Validate required fields and handle optional fields safely.
5. Do not invent missing scores, findings, file names or recommendations.
6. Display repository information when supplied:

   * Repository name and URL
   * Branch
   * Languages
   * Files analysed
7. Display overall and category scores only when returned.
8. Display severity counts only when returned or safely derived from actual findings.
9. Render detailed findings with file, line, category, severity, description and recommendation.
10. Render AI recommendations and code snippets when supplied.
11. Use safe DOM APIs and avoid inserting untrusted AI output with unsafe `innerHTML`.

### Deliverables

* Response adapter.
* Repository overview.
* Score and severity summaries.
* Detailed findings and recommendation views.

### Acceptance criteria

* Results are populated from actual n8n data.
* Missing fields display “Not available” or are omitted appropriately.
* Empty findings display a clear empty state.
* Invalid response structures produce a controlled error.
* No mock results are shown as genuine analysis.

\---

## Phase 6 – Findings interaction and report usability

### Goal

Make review results useful for developers and QA engineers.

### Implementation tasks

1. Add search across findings.
2. Add filters for severity, category and file.
3. Add sorting by severity, file and line number.
4. Add expandable finding details.
5. Show original and suggested code side by side when both are provided.
6. Add copy-to-clipboard for code snippets and recommendations.
7. Add clear labels when a suggested fix is AI-generated and has not been applied.
8. Add accessible table behavior and keyboard-friendly controls.

### Deliverables

* Searchable and filterable findings.
* Finding detail panel.
* Code comparison and copy actions.

### Acceptance criteria

* Filters and search operate on the actual findings.
* Selecting a finding displays its correct details.
* Copy actions work and provide user feedback.
* The UI does not imply that suggested fixes have been applied to GitHub.

\---

## Phase 7 – Review history, reports and persistence

### Goal

Add durable review records and export capabilities.

### Implementation tasks

1. Decide where review history will be stored.
2. If persistence is required, introduce a backend and database rather than relying on browser memory.
3. Store repository metadata, review timestamp, scores and findings.
4. Build a Review History page.
5. Allow users to reopen saved reports.
6. Add PDF, CSV or Excel export based on available report data.
7. Ensure exports contain only real findings and scores.
8. Add access controls if multiple users or teams use the application.

### Deliverables

* Persisted review history.
* Historical report view.
* Downloadable reports.

### Acceptance criteria

* A completed review can be reopened after refreshing or signing in again, if persistence is enabled.
* Exports match the displayed report.
* Failed or incomplete reviews are clearly labelled.

\---

## Phase 8 – Testing and production readiness

### Goal

Validate the application and prepare it for safe deployment.

### Implementation tasks

#### Functional testing

* Start review with valid selections.
* Start review with no selections.
* Verify one request is sent per click.
* Verify successful response rendering.
* Verify empty findings.
* Verify malformed JSON.
* Verify HTTP 4xx and 5xx responses.
* Verify network failure and timeout.
* Verify retry behavior.

#### Quality and deployment

* Test desktop, tablet and mobile layouts.
* Check accessibility and keyboard navigation.
* Add application logging and error monitoring.
* Configure environment-specific webhook settings.
* Build and deploy the frontend and any required backend proxy.

### Deliverables

* Test results.
* Security checklist.
* Production configuration.
* Deployment-ready application.

### Acceptance criteria

* Critical user journeys pass.
* Errors are handled without breaking the UI.
* Secrets are protected.
* Production webhook configuration is separate from development configuration.

\---

## Suggested project sequence

|Phase|Main output|Priority|
|-|-|-|
|0|Confirm webhook and JSON contract|Essential first|
|1|UI foundation|High|
|2|Dashboard and controls|High|
|3|Synchronous n8n integration|Critical|
|4|Loading and error states|High|
|5|Actual results rendering|Critical|
|6|Findings interactions|High|
|7|History and reports|Later|
|8|Security and production readiness|Before release|

## Recommended first release (MVP)

For the first usable release, complete Phases 0 through 6. Keep review history, database persistence, exports and advanced team features for a later release unless they are already supported by the existing system.

### MVP demonstration flow

1. Open CodeMind AI.
2. Select review modules.
3. Click Start Code Review.
4. Frontend sends a synchronous POST request to n8n.
5. n8n runs the existing GitHub and AI analysis workflow.
6. Frontend receives the completed response.
7. Dashboard displays repository information, scores, severity summary, findings and recommendations.
8. User searches findings, opens details and copies suggested code.

## Key implementation rule

Build the application incrementally. Complete and verify each phase before starting the next. Keep the n8n workflow as the source of repository retrieval and AI analysis; the frontend is responsible for triggering the workflow and presenting its returned data.

