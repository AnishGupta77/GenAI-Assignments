import { n8nConfig } from "./config";

export type ReviewWorkflowResponse = Record<string, unknown> | unknown[] | null;

export async function triggerReviewWorkflow(
  selectedModules: string[]
): Promise<ReviewWorkflowResponse> {
  if (!selectedModules.length) {
    throw new Error("No review modules selected.");
  }

  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), n8nConfig.timeoutMs);

  try {
    const response = await fetch(n8nConfig.webhookUrl, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        source: "codemind-ai",
        selectedModules,
        requestedAt: new Date().toISOString()
      }),
      signal: controller.signal
    });

    if (!response.ok) {
      throw new Error(`Review workflow request failed with status ${response.status}.`);
    }

    const rawBody = await response.text();

    if (!rawBody || rawBody.trim() === "") {
      throw new Error("The workflow returned an empty response body.");
    }

    try {
      return JSON.parse(rawBody) as ReviewWorkflowResponse;
    } catch {
      throw new Error("The workflow returned invalid JSON.");
    }
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error("The review request timed out. Please retry.");
    }

    if (error instanceof Error) {
      throw error;
    }

    throw new Error("Failed to submit the review request.");
  } finally {
    window.clearTimeout(timeoutId);
  }
}
