export type NormalizedFinding = {
  id: string;
  file: string;
  line: string;
  category: string;
  severity: string;
  description: string;
  recommendation: string;
  snippet?: string;
};

export type NormalizedReviewReport = {
  repository: {
    name: string;
    url: string;
    branch: string;
    languages: string[];
    filesAnalyzed: string;
  } | null;
  overallScore: string | null;
  categoryScores: Array<{ name: string; score: string }>;
  severityCounts: Record<string, number>;
  findings: NormalizedFinding[];
  recommendations: string[];
  raw: unknown;
};

function asArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  return value == null ? [] : [value];
}

function pickFirst(...values: Array<unknown>): unknown {
  for (const value of values) {
    if (value !== undefined && value !== null && value !== "") {
      return value;
    }
  }
  return null;
}

function normalizeText(value: unknown, fallback = "Not available"): string {
  if (typeof value === "string") {
    return value.trim() || fallback;
  }

  if (typeof value === "number") {
    return String(value);
  }

  if (typeof value === "boolean") {
    return value ? "true" : "false";
  }

  return fallback;
}

function normalizeScore(value: unknown): string | null {
  if (typeof value === "number") {
    return Number.isFinite(value) ? String(value) : null;
  }

  if (typeof value === "string") {
    const trimmed = value.trim();
    return trimmed || null;
  }

  return null;
}

function extractRepository(root: Record<string, unknown>): NormalizedReviewReport["repository"] {
  const repoInfo = pickFirst(root.repository, root.repo, root.repositoryInfo, root.repoInfo) as Record<string, unknown> | undefined;
  const source = repoInfo && typeof repoInfo === "object" ? repoInfo : root;

  if (!source || typeof source !== "object") return null;

  const repositoryName = normalizeText(
    pickFirst(
      (source as Record<string, unknown>).repositoryName,
      (source as Record<string, unknown>).repoName,
      (source as Record<string, unknown>).name,
      (source as Record<string, unknown>).repository
    ),
    "Not available"
  );

  const repositoryUrl = normalizeText(
    pickFirst(
      (source as Record<string, unknown>).repositoryUrl,
      (source as Record<string, unknown>).repoUrl,
      (source as Record<string, unknown>).html_url,
      (source as Record<string, unknown>).url
    ),
    "Not available"
  );

  const branch = normalizeText(
    pickFirst((source as Record<string, unknown>).branch, (source as Record<string, unknown>).defaultBranch),
    "Not available"
  );

  const languagesValue = pickFirst((source as Record<string, unknown>).languages, (source as Record<string, unknown>).language);
  const languages: string[] = Array.isArray(languagesValue)
    ? languagesValue.map((item) => normalizeText(item, "Not available"))
    : typeof languagesValue === "object" && languagesValue !== null
      ? Object.keys(languagesValue as Record<string, unknown>)
      : typeof languagesValue === "string"
        ? languagesValue.split(",").map((language) => language.trim()).filter(Boolean)
        : [];

  const filesAnalyzedValue = pickFirst(
    (source as Record<string, unknown>).filesAnalyzed,
    (source as Record<string, unknown>).files_analyzed,
    (source as Record<string, unknown>).totalFiles,
    (source as Record<string, unknown>).files
  );

  const filesAnalyzed = typeof filesAnalyzedValue === "number"
    ? String(filesAnalyzedValue)
    : Array.isArray(filesAnalyzedValue)
      ? String(filesAnalyzedValue.length)
      : normalizeText(filesAnalyzedValue, "Not available");

  if (repositoryName === "Not available" && repositoryUrl === "Not available" && branch === "Not available" && languages.length === 0) {
    return null;
  }

  return {
    name: repositoryName,
    url: repositoryUrl,
    branch,
    languages: languages.length ? languages : ["Not available"],
    filesAnalyzed
  };
}

function extractCategoryScores(root: Record<string, unknown>): Array<{ name: string; score: string }> {
  const scoreSource = pickFirst(root.categoryScores, root.category_scores, root.categories, root.scores) as Record<string, unknown> | undefined;
  if (!scoreSource || typeof scoreSource !== "object") return [];

  const entries: Array<{ name: string; score: string }> = [];

  if (Array.isArray(scoreSource)) {
    scoreSource.forEach((entry, index) => {
      if (typeof entry === "object" && entry !== null) {
        const record = entry as Record<string, unknown>;
        entries.push({
          name: normalizeText(pickFirst(record.name, record.category, record.label, `Category ${index + 1}`), `Category ${index + 1}`),
          score: normalizeScore(pickFirst(record.score, record.value, record.rating)) ?? "Not available"
        });
      }
    });
    return entries;
  }

  Object.entries(scoreSource).forEach(([key, value]) => {
    const score = normalizeScore(value);
    if (score) {
      entries.push({
        name: key.replace(/[_-]/g, " ").replace(/\b\w/g, (char) => char.toUpperCase()),
        score
      });
    }
  });

  return entries;
}

function extractFindings(root: Record<string, unknown>): NormalizedFinding[] {
  const findingsSource = pickFirst(
    root.findings,
    root.issues,
    root.results,
    root.vulnerabilities,
    root.reviewFindings
  );

  const findings = asArray(findingsSource);

  if (findings.length === 0 && root && typeof root === "object") {
    const possibleKeys = ["finding", "issue", "result"] as const;
    for (const key of possibleKeys) {
      const value = root[key];
      if (value) {
        return extractFindings({ findings: value } as Record<string, unknown>);
      }
    }
  }

  return findings
    .map((finding, index) => {
      if (typeof finding !== "object" || finding === null) {
        return null;
      }

      const record = finding as Record<string, unknown>;
      const file = normalizeText(
        pickFirst(record.file, record.path, record.filePath, record.filename, record.location),
        "Not available"
      );
      const line = normalizeText(
        pickFirst(record.line, record.lineNumber, record.startLine, record.start_line, record.locationLine),
        "Not available"
      );
      const category = normalizeText(
        pickFirst(record.category, record.type, record.label, record.title, "General"),
        "General"
      );
      const severity = normalizeText(
        pickFirst(record.severity, record.level, record.priority, record.risk, "Unknown"),
        "Unknown"
      );
      const description = normalizeText(
        pickFirst(record.description, record.message, record.details, record.summary, record.title),
        "No description provided."
      );
      const recommendation = normalizeText(
        pickFirst(
          record.recommendation,
          record.suggestedFix,
          record.fix,
          record.remediation,
          record.solution,
          "No recommendation provided."
        ),
        "No recommendation provided."
      );
      const snippet = normalizeText(
        pickFirst(record.snippet, record.code, record.example, record.before, record.after),
        ""
      );

      return {
        id: `finding-${index + 1}`,
        file,
        line,
        category,
        severity,
        description,
        recommendation,
        snippet: snippet !== "" ? snippet : undefined
      };
    })
    .filter(Boolean) as NormalizedFinding[];
}

function extractRecommendations(root: Record<string, unknown>): string[] {
  const recs = pickFirst(root.recommendations, root.suggestions, root.aiRecommendations, root.recommendation) as unknown;
  if (Array.isArray(recs)) {
    return recs.map((item) => normalizeText(item, "No recommendation provided."));
  }

  if (typeof recs === "string") {
    return [recs];
  }

  if (typeof recs === "object" && recs !== null) {
    return Object.values(recs as Record<string, unknown>).map((item) => normalizeText(item, "No recommendation provided."));
  }

  return [];
}

function extractSeverityCounts(findings: NormalizedFinding[], root: Record<string, unknown>): Record<string, number> {
  const summary = root.summary as Record<string, unknown> | undefined;
  const directCounts = pickFirst(
    root.severityCounts,
    root.severity_count,
    root.severitySummary,
    summary && summary.severityCounts
  ) as Record<string, unknown> | undefined;

  if (directCounts && typeof directCounts === "object") {
    return Object.entries(directCounts).reduce<Record<string, number>>((acc, [key, value]) => {
      acc[key] = typeof value === "number" ? value : Number(value || 0);
      return acc;
    }, {});
  }

  return findings.reduce<Record<string, number>>((acc, finding) => {
    const severity = finding.severity || "Unknown";
    acc[severity] = (acc[severity] || 0) + 1;
    return acc;
  }, {});
}

export function normalizeReviewResponse(payload: unknown): NormalizedReviewReport | null {
  if (payload == null) return null;

  const candidate = Array.isArray(payload) && payload.length === 1 ? payload[0] : payload;
  if (typeof candidate !== "object" || candidate === null) return null;

  const root = candidate as Record<string, unknown>;
  const reportRoot = pickFirst(root.data, root.result, root.report, root.review, root.response) as Record<string, unknown> | undefined;
  const effectiveRoot = (reportRoot && typeof reportRoot === "object" ? reportRoot : root) as Record<string, unknown>;
  const summary = effectiveRoot.summary as Record<string, unknown> | undefined;

  const findings = extractFindings(effectiveRoot);
  const repository = extractRepository(effectiveRoot);
  const categoryScores = extractCategoryScores(effectiveRoot);
  const overallScore = normalizeScore(
    pickFirst(
      effectiveRoot.overallScore,
      effectiveRoot.overall_score,
      effectiveRoot.score,
      summary && summary.overallScore,
      summary && summary.score,
      summary && summary.overall
    )
  );

  return {
    repository,
    overallScore,
    categoryScores,
    severityCounts: extractSeverityCounts(findings, effectiveRoot),
    findings,
    recommendations: extractRecommendations(effectiveRoot),
    raw: payload
  };
}
