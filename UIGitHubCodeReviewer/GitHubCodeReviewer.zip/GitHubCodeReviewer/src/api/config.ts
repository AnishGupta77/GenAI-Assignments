const readEnv = (key: string, fallback: string) => {
  const value = import.meta.env[key];
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : fallback;
};

const readTimeout = (fallback: number) => {
  const rawValue = Number(readEnv("VITE_N8N_TIMEOUT_MS", String(fallback)));
  return Number.isFinite(rawValue) && rawValue > 0 ? rawValue : fallback;
};

export const n8nConfig = {
  webhookUrl: readEnv("VITE_N8N_WEBHOOK_URL", "http://localhost:5678/webhook/Github_review"),
  timeoutMs: readTimeout(45000)
};
