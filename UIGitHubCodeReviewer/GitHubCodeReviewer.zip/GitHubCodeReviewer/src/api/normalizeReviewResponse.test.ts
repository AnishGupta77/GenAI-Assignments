import { describe, expect, it } from "vitest";

import { normalizeReviewResponse } from "./normalizeReviewResponse";
import { triggerReviewWorkflow } from "./reviewService";

describe("normalizeReviewResponse", () => {
  it("normalizes a complete review payload into the frontend model", () => {
    const payload = {
      repository: {
        name: "demo-app",
        url: "https://github.com/demo/demo-app",
        branch: "main",
        languages: ["TypeScript", "CSS"],
        filesAnalyzed: 42
      },
      overallScore: 91,
      categoryScores: [
        { name: "security", score: 93 },
        { name: "performance", score: 88 }
      ],
      findings: [
        {
          file: "src/app.ts",
          line: 18,
          severity: "High",
          category: "Security",
          description: "Unvalidated user input reaches the API.",
          recommendation: "Validate input server-side before sending it to the request layer.",
          snippet: "const value = req.body.input;"
        }
      ],
      recommendations: ["Add validation and rate limiting."],
      summary: {
        severityCounts: { High: 1, Medium: 2 }
      }
    };

    const normalized = normalizeReviewResponse(payload);

    expect(normalized).not.toBeNull();
    expect(normalized?.repository?.name).toBe("demo-app");
    expect(normalized?.overallScore).toBe("91");
    expect(normalized?.categoryScores[0]).toEqual({ name: "security", score: "93" });
    expect(normalized?.findings).toHaveLength(1);
    expect(normalized?.severityCounts).toEqual({ High: 1, Medium: 2 });
    expect(normalized?.recommendations).toEqual(["Add validation and rate limiting."]);
  });

  it("returns null for malformed or empty payloads", () => {
    expect(normalizeReviewResponse(null)).toBeNull();
    expect(normalizeReviewResponse("bad payload")).toBeNull();
  });
});

describe("triggerReviewWorkflow", () => {
  it("rejects requests when no modules are selected", async () => {
    await expect(triggerReviewWorkflow([])).rejects.toThrow("No review modules selected.");
  });
});
