import { useEffect, useMemo, useState } from "react";
import { normalizeReviewResponse, type NormalizedReviewReport } from "./api/normalizeReviewResponse";
import { triggerReviewWorkflow } from "./api/reviewService";

type ReviewModule = {
  id: string;
  label: string;
  checked: boolean;
};

type SortOption = "severity" | "file" | "line";
type SavedReviewEntry = {
  id: string;
  savedAt: string;
  selectedModules: string[];
  report: NormalizedReviewReport;
};

const STORAGE_KEY = "codemind-ai-review-history";

const severityRank: Record<string, number> = {
  Critical: 4,
  High: 3,
  Medium: 2,
  Low: 1,
  Unknown: 0
};

const defaultModules: ReviewModule[] = [
  { id: "quality", label: "Code Quality", checked: true },
  { id: "security", label: "Security Analysis", checked: true },
  { id: "performance", label: "Performance", checked: false },
  { id: "standards", label: "Coding Standards", checked: true },
  { id: "maintainability", label: "Maintainability", checked: false },
  { id: "tests", label: "Test Automation Review", checked: false }
];

const metricCards = [
  { label: "Repos Analyzed", value: "—", hint: "Historical snapshot only" },
  { label: "Avg. Review", value: "—", hint: "Awaiting first workflow run" },
  { label: "Security Flags", value: "—", hint: "No live findings yet" },
  { label: "Coverage", value: "—", hint: "Neutral historical baseline" }
];

const waitingMessages = [
  "Sending review request...",
  "Waiting for repository analysis...",
  "Waiting for AI review results...",
  "Preparing the report..."
];

export default function App() {
  const [modules, setModules] = useState(defaultModules);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [responsePayload, setResponsePayload] = useState<NormalizedReviewReport | null>(null);
  const [activeMessageIndex, setActiveMessageIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [severityFilter, setSeverityFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [fileFilter, setFileFilter] = useState("all");
  const [sortOption, setSortOption] = useState<SortOption>("severity");
  const [selectedFindingId, setSelectedFindingId] = useState<string | null>(null);
  const [copyMessage, setCopyMessage] = useState<string | null>(null);
  const [historyEntries, setHistoryEntries] = useState<SavedReviewEntry[]>([]);
  const [historyView, setHistoryView] = useState<"dashboard" | "history">("dashboard");

  const selectedCount = useMemo(
    () => modules.filter((module) => module.checked).length,
    [modules]
  );

  const toggleModule = (id: string) => {
    setModules((current) =>
      current.map((module) =>
        module.id === id ? { ...module, checked: !module.checked } : module
      )
    );
  };

  const selectAll = () => {
    setModules((current) => current.map((module) => ({ ...module, checked: true })));
  };

  const clearAll = () => {
    setModules((current) => current.map((module) => ({ ...module, checked: false })));
  };

  const handleReviewStart = async () => {
    if (selectedCount === 0 || isSubmitting) {
      return;
    }

    const selectedModules = modules
      .filter((module) => module.checked)
      .map((module) => module.id);

    setIsSubmitting(true);
    setSubmitError(null);
    setResponsePayload(null);
    setSelectedFindingId(null);

    try {
      const result = await triggerReviewWorkflow(selectedModules);
      const normalized = normalizeReviewResponse(result);

      if (!normalized) {
        throw new Error("The workflow returned a response payload that does not match the expected review structure.");
      }

      setResponsePayload(normalized);
      saveReviewToHistory(normalized, selectedModules);
    } catch (error) {
      setSubmitError(
        error instanceof Error ? error.message : "The review workflow could not be completed."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const findings = responsePayload?.findings ?? [];

  const filteredFindings = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    const next = findings.filter((finding) => {
      const matchesSearch =
        query.length === 0 ||
        [finding.file, finding.line, finding.category, finding.severity, finding.description, finding.recommendation]
          .join(" ")
          .toLowerCase()
          .includes(query);

      const matchesSeverity = severityFilter === "all" || finding.severity === severityFilter;
      const matchesCategory = categoryFilter === "all" || finding.category === categoryFilter;
      const matchesFile = fileFilter === "all" || finding.file === fileFilter;

      return matchesSearch && matchesSeverity && matchesCategory && matchesFile;
    });

    next.sort((left, right) => {
      switch (sortOption) {
        case "file":
          return left.file.localeCompare(right.file) || Number(left.line) - Number(right.line);
        case "line":
          return Number(left.line) - Number(right.line) || left.file.localeCompare(right.file);
        case "severity":
        default:
          return (
            (severityRank[right.severity] ?? 0) - (severityRank[left.severity] ?? 0) ||
            left.file.localeCompare(right.file)
          );
      }
    });

    return next;
  }, [findings, searchTerm, severityFilter, categoryFilter, fileFilter, sortOption]);

  const selectedFinding =
    filteredFindings.find((finding) => finding.id === selectedFindingId) ?? filteredFindings[0] ?? null;

  useEffect(() => {
    if (!selectedFinding && filteredFindings[0]) {
      setSelectedFindingId(filteredFindings[0].id);
      return;
    }

    if (selectedFinding && !filteredFindings.some((finding) => finding.id === selectedFinding.id)) {
      setSelectedFindingId(filteredFindings[0]?.id ?? null);
    }
  }, [filteredFindings, selectedFinding]);

  useEffect(() => {
    if (!isSubmitting) {
      setActiveMessageIndex(0);
      return;
    }

    const intervalId = window.setInterval(() => {
      setActiveMessageIndex((current) => (current + 1) % waitingMessages.length);
    }, 1800);

    return () => window.clearInterval(intervalId);
  }, [isSubmitting]);

  useEffect(() => {
    if (!copyMessage) {
      return undefined;
    }

    const timeoutId = window.setTimeout(() => setCopyMessage(null), 1800);
    return () => window.clearTimeout(timeoutId);
  }, [copyMessage]);

  const severityOptions = [...new Set(findings.map((finding) => finding.severity))];
  const categoryOptions = [...new Set(findings.map((finding) => finding.category))];
  const fileOptions = [...new Set(findings.map((finding) => finding.file))];

  const handleCopy = async (value: string | undefined, label: string) => {
    if (!value) {
      return;
    }

    try {
      await navigator.clipboard.writeText(value);
      setCopyMessage(`${label} copied to clipboard.`);
    } catch {
      setCopyMessage(`Unable to copy ${label.toLowerCase()} automatically.`);
    }
  };

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as SavedReviewEntry[];
      if (Array.isArray(parsed)) {
        setHistoryEntries(parsed);
      }
    } catch {
      setHistoryEntries([]);
    }
  }, []);

  const saveReviewToHistory = (report: NormalizedReviewReport, selectedModules: string[]) => {
    const entry: SavedReviewEntry = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      savedAt: new Date().toISOString(),
      selectedModules,
      report
    };

    setHistoryEntries((previous) => {
      const next = [entry, ...previous].slice(0, 12);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  const exportCurrentReport = () => {
    if (!responsePayload) {
      return;
    }

    const rows = [
      ["repository", responsePayload.repository?.name ?? "Not available"],
      ["overallScore", responsePayload.overallScore ?? "Not available"],
      ["", ""],
      ["file", "line", "severity", "category", "description", "recommendation"]
    ];

    responsePayload.findings.forEach((finding) => {
      rows.push([
        finding.file,
        finding.line,
        finding.severity,
        finding.category,
        finding.description,
        finding.recommendation
      ]);
    });

    const csvContent = rows
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${responsePayload.repository?.name ?? "review-report"}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
    setCopyMessage("Report exported as CSV.");
  };

  const isReviewDisabled = selectedCount === 0 || isSubmitting;

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="logo-mark">C</div>
          <div>
            <p className="eyebrow">AI GitHub Reviewer</p>
            <h1>CodeMind AI</h1>
          </div>
        </div>

        <nav className="nav" aria-label="Main navigation">
          <a href="#dashboard">Dashboard</a>
          <a href="#analysis">Repository Analysis</a>
          <a href="#reports">Reports</a>
        </nav>

        <button
          className="ghost-button"
          type="button"
          onClick={() => setHistoryView((current) => (current === "dashboard" ? "history" : "dashboard"))}
        >
          {historyView === "dashboard" ? "View History" : "Back to Dashboard"}
        </button>
      </header>

      {historyView === "history" ? (
        <main className="dashboard history-page" id="history">
          <section className="hero-card history-hero">
            <div>
              <p className="eyebrow text-cyan">Review history</p>
              <h2>Saved reports</h2>
            </div>
            <button className="chip-button" type="button" onClick={() => setHistoryView("dashboard")}>
              Open dashboard
            </button>
          </section>

          {historyEntries.length === 0 ? (
            <div className="empty-state history-empty">
              <h3>No reports saved yet</h3>
              <p>Completed reviews will appear here for quick reuse and export.</p>
            </div>
          ) : (
            <div className="history-list">
              {historyEntries.map((entry) => (
                <article key={entry.id} className="history-item">
                  <div>
                    <p className="eyebrow text-cyan">{new Date(entry.savedAt).toLocaleString()}</p>
                    <h3>{entry.report.repository?.name ?? "Repository report"}</h3>
                  </div>
                  <div className="history-summary">
                    <span>{entry.selectedModules.join(", ") || "No modules selected"}</span>
                    <strong>{entry.report.overallScore ?? "No score"}</strong>
                  </div>
                  <div className="history-actions">
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => {
                        setResponsePayload(entry.report);
                        setHistoryView("dashboard");
                      }}
                    >
                      Reopen report
                    </button>
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => {
                        const rows = [
                          ["repository", entry.report.repository?.name ?? "Not available"],
                          ["overallScore", entry.report.overallScore ?? "Not available"],
                          ["", ""],
                          ["file", "line", "severity", "category", "description", "recommendation"]
                        ];
                        entry.report.findings.forEach((finding) => {
                          rows.push([
                            finding.file,
                            finding.line,
                            finding.severity,
                            finding.category,
                            finding.description,
                            finding.recommendation
                          ]);
                        });
                        const csv = rows
                          .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
                          .join("\n");
                        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
                        const url = URL.createObjectURL(blob);
                        const anchor = document.createElement("a");
                        anchor.href = url;
                        anchor.download = `${entry.report.repository?.name ?? "review-history"}.csv`;
                        anchor.click();
                        URL.revokeObjectURL(url);
                        setCopyMessage("Saved report exported to CSV.");
                      }}
                    >
                      Export CSV
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </main>
      ) : (
        <main className="dashboard" id="dashboard">
          <section className="hero-card">
          <div>
            <p className="eyebrow text-cyan">Review Workspace</p>
            <h2>Repository Code Analyzer</h2>
          </div>
          <button className="chip-button" type="button">
            {isSubmitting ? "Review in progress" : "Workflow pending"}
          </button>
        </section>

        <section className="metrics-grid" aria-label="Dashboard metrics">
          {metricCards.map((metric) => (
            <article key={metric.label} className="metric-card">
              <p>{metric.label}</p>
              <strong>{metric.value}</strong>
              <span>{metric.hint}</span>
            </article>
          ))}
        </section>

        <section className="content-grid">
          <aside className="panel review-panel" id="analysis">
            <div className="panel-header">
              <h3>Repository Code Analyzer</h3>
              <span className="module-count">{selectedCount} selected</span>
            </div>

            <div className="module-list" aria-label="Review modules">
              {modules.map((module) => (
                <label key={module.id} className="module-option">
                  <input
                    type="checkbox"
                    checked={module.checked}
                    onChange={() => toggleModule(module.id)}
                    disabled={isSubmitting}
                  />
                  <span>{module.label}</span>
                </label>
              ))}
            </div>

            <div className="panel-actions">
              <button className="secondary-button" type="button" onClick={selectAll}>
                Select All
              </button>
              <button className="secondary-button" type="button" onClick={clearAll}>
                Clear
              </button>
            </div>

            <button
              className="primary-button"
              type="button"
              disabled={isReviewDisabled}
              aria-disabled={isReviewDisabled}
              onClick={handleReviewStart}
            >
              {isSubmitting ? "Reviewing..." : "Start Code Review"}
            </button>
          </aside>

          <section className="panel results-panel" id="reports" aria-live="polite">
            {submitError ? (
              <div className="status-card error-card">
                <h3>Review request failed</h3>
                <p>{submitError}</p>
                <button
                  className="secondary-button retry-button"
                  type="button"
                  onClick={handleReviewStart}
                  disabled={isSubmitting}
                >
                  Retry
                </button>
              </div>
            ) : isSubmitting ? (
              <div className="status-card loading-card">
                <div className="spinner" aria-hidden="true" />
                <h3>Review in progress</h3>
                <p className="rotating-message">{waitingMessages[activeMessageIndex]}</p>
                <ul className="status-message-list">
                  {waitingMessages.map((message, index) => (
                    <li key={message} className={index === activeMessageIndex ? "active" : ""}>
                      {message}
                    </li>
                  ))}
                </ul>
              </div>
            ) : responsePayload ? (
              <div className="report-card">
                <div className="report-header">
                  <div>
                    <p className="eyebrow text-cyan">Repository overview</p>
                    <h3>{responsePayload.repository?.name ?? "Repository name not available"}</h3>
                  </div>
                  <div className="report-header-actions">
                    {responsePayload.overallScore ? (
                      <div className="score-badge">{responsePayload.overallScore}</div>
                    ) : null}
                    <button className="secondary-button" type="button" onClick={exportCurrentReport}>
                      Export CSV
                    </button>
                  </div>
                </div>

                <div className="report-grid">
                  <div className="report-block">
                    <h4>Repository details</h4>
                    <dl>
                      <div>
                        <dt>URL</dt>
                        <dd>{responsePayload.repository?.url ?? "Not available"}</dd>
                      </div>
                      <div>
                        <dt>Branch</dt>
                        <dd>{responsePayload.repository?.branch ?? "Not available"}</dd>
                      </div>
                      <div>
                        <dt>Languages</dt>
                        <dd>{responsePayload.repository?.languages.join(", ") ?? "Not available"}</dd>
                      </div>
                      <div>
                        <dt>Files analysed</dt>
                        <dd>{responsePayload.repository?.filesAnalyzed ?? "Not available"}</dd>
                      </div>
                    </dl>
                  </div>

                  {responsePayload.categoryScores.length > 0 ? (
                    <div className="report-block">
                      <h4>Category scores</h4>
                      <ul className="score-list">
                        {responsePayload.categoryScores.map((score) => (
                          <li key={score.name}>
                            <span>{score.name}</span>
                            <strong>{score.score}</strong>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                </div>

                {Object.keys(responsePayload.severityCounts).length > 0 ? (
                  <div className="report-block">
                    <h4>Severity summary</h4>
                    <ul className="severity-list">
                      {Object.entries(responsePayload.severityCounts).map(([level, count]) => (
                        <li key={level}>
                          <span>{level}</span>
                          <strong>{count}</strong>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                {responsePayload.recommendations.length > 0 ? (
                  <div className="report-block">
                    <h4>AI recommendations</h4>
                    <ul className="recommendation-list">
                      {responsePayload.recommendations.map((recommendation, index) => (
                        <li key={`${recommendation}-${index}`}>{recommendation}</li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                <div className="report-block findings-block">
                  <div className="findings-header">
                    <h4>Detailed findings</h4>
                    {copyMessage ? <span className="copy-feedback">{copyMessage}</span> : null}
                  </div>

                  {findings.length > 0 ? (
                    <>
                      <div className="findings-tools" aria-label="Finding filters and search">
                        <input
                          className="finding-search"
                          type="search"
                          value={searchTerm}
                          onChange={(event) => setSearchTerm(event.target.value)}
                          placeholder="Search findings..."
                          aria-label="Search findings"
                        />

                        <select
                          value={severityFilter}
                          onChange={(event) => setSeverityFilter(event.target.value)}
                          aria-label="Filter findings by severity"
                        >
                          <option value="all">All severities</option>
                          {severityOptions.map((severity) => (
                            <option key={severity} value={severity}>
                              {severity}
                            </option>
                          ))}
                        </select>

                        <select
                          value={categoryFilter}
                          onChange={(event) => setCategoryFilter(event.target.value)}
                          aria-label="Filter findings by category"
                        >
                          <option value="all">All categories</option>
                          {categoryOptions.map((category) => (
                            <option key={category} value={category}>
                              {category}
                            </option>
                          ))}
                        </select>

                        <select
                          value={fileFilter}
                          onChange={(event) => setFileFilter(event.target.value)}
                          aria-label="Filter findings by file"
                        >
                          <option value="all">All files</option>
                          {fileOptions.map((file) => (
                            <option key={file} value={file}>
                              {file}
                            </option>
                          ))}
                        </select>

                        <select
                          value={sortOption}
                          onChange={(event) => setSortOption(event.target.value as SortOption)}
                          aria-label="Sort findings"
                        >
                          <option value="severity">Sort by severity</option>
                          <option value="file">Sort by file</option>
                          <option value="line">Sort by line</option>
                        </select>
                      </div>

                      {filteredFindings.length === 0 ? (
                        <p className="empty-finding-state">No findings match the current search and filters.</p>
                      ) : (
                        <div className="findings-layout">
                          <div className="finding-list-panel">
                            {filteredFindings.map((finding) => (
                              <button
                                key={finding.id}
                                type="button"
                                className={`finding-item-button ${selectedFinding?.id === finding.id ? "selected" : ""}`}
                                onClick={() => setSelectedFindingId(finding.id)}
                                aria-pressed={selectedFinding?.id === finding.id}
                              >
                                <div className="finding-item-topline">
                                  <span className="finding-file">{finding.file}</span>
                                  <span className="finding-line">Line {finding.line}</span>
                                </div>
                                <div className="finding-item-meta">
                                  <span className="finding-severity">{finding.severity}</span>
                                  <span className="finding-category">{finding.category}</span>
                                </div>
                                <p>{finding.description}</p>
                              </button>
                            ))}
                          </div>

                          <aside className="finding-detail-panel">
                            {selectedFinding ? (
                              <>
                                <div className="finding-detail-header">
                                  <span className="finding-file">{selectedFinding.file}</span>
                                  <span className="finding-line">Line {selectedFinding.line}</span>
                                </div>
                                <div className="finding-detail-meta">
                                  <span className="finding-severity">{selectedFinding.severity}</span>
                                  <span className="finding-category">{selectedFinding.category}</span>
                                </div>
                                <p className="finding-detail-description">{selectedFinding.description}</p>
                                <div className="finding-detail-section">
                                  <strong>Recommendation</strong>
                                  <p>{selectedFinding.recommendation}</p>
                                </div>
                                <div className="code-comparison">
                                  {selectedFinding.snippet ? (
                                    <div className="code-panel">
                                      <div className="code-panel-header">
                                        <span>Current code</span>
                                        <button
                                          type="button"
                                          className="mini-button"
                                          onClick={() => handleCopy(selectedFinding.snippet, "Code snippet")}
                                        >
                                          Copy
                                        </button>
                                      </div>
                                      <pre>{selectedFinding.snippet}</pre>
                                    </div>
                                  ) : null}

                                  <div className="code-panel">
                                    <div className="code-panel-header">
                                      <span>AI-generated fix</span>
                                      <button
                                        type="button"
                                        className="mini-button"
                                        onClick={() => handleCopy(selectedFinding.recommendation, "Recommendation")}
                                      >
                                        Copy
                                      </button>
                                    </div>
                                    <pre>{selectedFinding.recommendation}</pre>
                                  </div>
                                </div>
                              </>
                            ) : (
                              <p className="empty-finding-state">Select a finding to view its details.</p>
                            )}
                          </aside>
                        </div>
                      )}
                    </>
                  ) : (
                    <p className="empty-finding-state">No findings were returned in this review response.</p>
                  )}
                </div>
              </div>
            ) : (
              <div className="empty-state">
                <div className="spinner" aria-hidden="true" />
                <h3>Review Workspace waiting</h3>
                <p>
                  Select one or more review modules to prepare the analysis request. The
                  dashboard is intentionally neutral until the workflow returns live data.
                </p>
              </div>
            )}
          </section>
        </section>
      </main>
    )}
  </div>
  );
}
